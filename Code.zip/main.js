let monProjet3 = new Projet3();
monProjet3.initDiaporama();
monProjet3.initCarte();
monProjet3.initStorage();
monProjet3.initCanvas();
monProjet3.initDelete();
monProjet3.initCompteurFooter();